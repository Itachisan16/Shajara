/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion, AnimatePresence } from "motion/react";
import { TreeDeciduous, Heart, Calendar, Users, ChevronDown, User } from "lucide-react";
import { useState } from "react";

// --- Types ---
interface Person {
  name: string;
  birthYear: number | string;
  role?: string;
  relation?: string;
  gender?: 'male' | 'female';
}

interface FamilyData {
  paternal: {
    grandfather: Person;
    grandmother: Person;
  };
  maternal: {
    grandfather: Person;
    grandmother: Person;
  };
  parents: {
    father: Person;
    mother: Person;
  };
  children: Person[];
}

// --- Data ---
const family: FamilyData = {
  paternal: {
    grandfather: { name: "Solijon", birthYear: 1950, relation: "Bobom (Dadamni Otasi)", gender: 'male' },
    grandmother: { name: "Dilbarxon", birthYear: 1956, relation: "Buvi (Dadamni Onasi)", gender: 'female' },
  },
  maternal: {
    grandfather: { name: "Sharipjon", birthYear: 1946, relation: "Bobom (Onamni Otasi)", gender: 'male' },
    grandmother: { name: "Muharramxon", birthYear: 1946, relation: "Buvim (Onamni Onasi)", gender: 'female' },
  },
  parents: {
    father: { name: "Sherzod", birthYear: 1979, relation: "Otam", gender: 'male' },
    mother: { name: "Gulandom", birthYear: 1981, relation: "Onam", gender: 'female' },
  },
  children: [
    { name: "Javohir", birthYear: "Katta farzand", role: "Akasi", gender: 'male' },
    { name: "Bahodir", birthYear: "O'rta farzand", role: "O'zim", gender: 'male' },
    { name: "Sardor", birthYear: "Kichik farzand", role: "Ukasi", gender: 'male' },
  ],
};

// --- Components ---

const Leaf = ({ className = "", delay = 0 }: { className?: string; delay?: number }) => (
  <motion.div
    initial={{ opacity: 0, rotate: -20 }}
    animate={{ opacity: 0.1, rotate: [0, 10, 0] }}
    transition={{ delay, duration: 4, repeat: Infinity, ease: "easeInOut" }}
    className={`absolute text-green-800 pointer-events-none ${className}`}
  >
    <TreeDeciduous size={120} />
  </motion.div>
);

const MemberCard = ({ person, delay = 0 }: { person: Person; delay?: number }) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ delay, duration: 0.7, type: "spring", stiffness: 100 }}
      whileHover={{ y: -8, scale: 1.05 }}
      className="relative group"
    >
      <div className={`p-5 rounded-3xl bg-white/80 backdrop-blur-md shadow-[0_10px_30px_rgb(0,0,0,0.04)] border border-white/50 flex flex-col items-center text-center min-w-[180px] transition-all duration-300 group-hover:shadow-[0_20px_40px_rgb(0,0,0,0.08)] group-hover:border-green-200`}>
        <div className={`w-16 h-16 rounded-2xl mb-4 flex items-center justify-center shadow-inner transition-transform duration-500 group-hover:rotate-6 ${person.gender === 'male' ? 'bg-blue-100/50 text-blue-600' : 'bg-pink-100/50 text-pink-600'}`}>
          <User size={32} strokeWidth={1.5} />
        </div>
        
        <h3 className="font-serif font-bold text-xl text-slate-800 leading-tight mb-1">{person.name}</h3>
        <p className="text-[10px] font-bold text-green-700/60 uppercase tracking-[0.2em] mb-3">{person.relation || person.role}</p>
        
        <div className="flex items-center gap-2 px-3 py-1 bg-slate-100/50 rounded-full text-slate-500">
          <Calendar size={12} />
          <span className="text-xs font-mono font-medium">{person.birthYear}</span>
        </div>
      </div>
      
      {/* Decorative root/leaf element */}
      <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-4 h-4 bg-green-500/10 rounded-full blur-sm group-hover:bg-green-500/30 transition-colors" />
    </motion.div>
  );
};

const ConnectingLine = ({ className = "" }: { className?: string }) => (
  <div className={`h-8 w-px bg-slate-200 ${className}`} />
);

export default function App() {
  const [showGrandparents, setShowGrandparents] = useState(true);

  return (
    <div className="min-h-screen bg-[#f5f5f0] text-slate-900 px-4 py-12 md:py-20 overflow-x-hidden selection:bg-green-100 italic-small">
      {/* Background decoration */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <Leaf className="-top-10 -left-10" delay={0} />
        <Leaf className="top-1/4 -right-20" delay={1} />
        <Leaf className="bottom-1/4 -left-20" delay={2} />
        <Leaf className="-bottom-10 right-10" delay={3} />
      </div>

      <div className="max-w-6xl mx-auto flex flex-col items-center relative z-10">
        <motion.header 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 text-green-700 mb-6 shadow-sm">
            <TreeDeciduous size={32} />
          </div>
          <h1 className="text-4xl md:text-6xl font-serif font-bold text-slate-900 mb-4 tracking-tight">
            Sherzod & Gulandom <br className="sm:hidden" />
            <span className="text-green-700 italic">Oila Shajarasi</span>
          </h1>
          <p className="max-w-xl mx-auto text-slate-500 font-medium leading-relaxed">
            Bizning oilamizning tarixi va ajdodlarimiz haqidagi ma'lumotlar. 
            Olingan barcha ma'lumotlar avloddan-avlodga o'tib kelmoqda.
          </p>
        </motion.header>

        {/* Tree Structure */}
        <div className="w-full flex flex-col items-center gap-4 py-10 relative">
          
          {/* Vertical Trunk Line */}
          <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-[2px] bg-gradient-to-b from-transparent via-green-100 to-transparent hidden md:block" />

          {/* Layer 1: Grandparents */}
          <AnimatePresence>
            {showGrandparents && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-40 w-full max-w-6xl px-4 mb-12">
                {/* Paternal */}
                <div className="flex flex-col items-center">
                  <div className="px-4 py-1 bg-blue-50 text-blue-500 rounded-full text-[10px] uppercase tracking-widest font-bold mb-8 shadow-sm">Otaning ota-onasi</div>
                  <div className="flex gap-6 relative">
                    <MemberCard person={family.paternal.grandfather} delay={0.1} />
                    <MemberCard person={family.paternal.grandmother} delay={0.2} />
                    {/* Bracket */}
                    <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 w-1/2 h-8 border-x-2 border-b-2 border-green-100 rounded-b-3xl" />
                  </div>
                  <div className="h-12 w-px bg-green-100 mt-8" />
                </div>

                {/* Maternal */}
                <div className="flex flex-col items-center">
                  <div className="px-4 py-1 bg-pink-50 text-pink-500 rounded-full text-[10px] uppercase tracking-widest font-bold mb-8 shadow-sm">Onaning ota-onasi</div>
                  <div className="flex gap-6 relative">
                    <MemberCard person={family.maternal.grandfather} delay={0.3} />
                    <MemberCard person={family.maternal.grandmother} delay={0.4} />
                    {/* Bracket */}
                    <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 w-1/2 h-8 border-x-2 border-b-2 border-green-100 rounded-b-3xl" />
                  </div>
                  <div className="h-12 w-px bg-green-100 mt-8" />
                </div>
              </div>
            )}
          </AnimatePresence>

          {/* Horizontal Connector for Parents */}
          <div className="hidden md:block w-3/4 h-[2px] bg-green-50 mb-12" />

          {/* Layer 2: Parents */}
          <div className="flex flex-col items-center relative mb-16">
            <div className="flex items-center gap-6 md:gap-16 relative">
              <MemberCard person={family.parents.father} delay={0.5} />
              
              <motion.div 
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="z-10 p-3 bg-white rounded-full shadow-lg border border-pink-50 text-pink-400"
              >
                <Heart className="fill-pink-400" size={24} />
              </motion.div>

              <MemberCard person={family.parents.mother} delay={0.6} />
            </div>
            
            {/* Trunk to children */}
            <div className="h-20 w-[2px] bg-gradient-to-b from-green-200 to-green-100 mt-4 relative">
                 <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-4 h-4 bg-green-100 rounded-full blur-sm" />
            </div>
          </div>

          {/* Layer 3: Children */}
          <div className="w-full max-w-5xl flex flex-col items-center">
            <div className="hidden md:flex justify-between w-[80%] h-12 border-x-2 border-t-2 border-green-100 rounded-t-[40px] mb-8" />
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full">
              {family.children.map((child, idx) => (
                <div key={child.name} className="flex flex-col items-center">
                    <div className="md:hidden h-8 w-px bg-green-100 mb-4" />
                    <MemberCard person={child} delay={0.7 + idx * 0.1} />
                </div>
              ))}
            </div>
          </div>
        </div>

        <footer className="mt-24 pt-12 border-t border-slate-200 w-full text-center text-slate-400 text-sm">
          <p>&copy; {new Date().getFullYear()} Shajara - Oila Daraxti. Bahodir tomonidan tayyorlandi.</p>
        </footer>
      </div>

      {/* Font imports */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;0,900;1,400&family=Inter:wght@300;400;500;600&family=JetBrains+Mono&display=swap');
        
        :root {
          --font-serif: 'Playfair Display', serif;
          --font-sans: 'Inter', sans-serif;
          --font-mono: 'JetBrains Mono', monospace;
        }

        .font-serif { font-family: var(--font-serif); }
        .font-sans { font-family: var(--font-sans); }
        .font-mono { font-family: var(--font-mono); }
      `}</style>
    </div>
  );
}
